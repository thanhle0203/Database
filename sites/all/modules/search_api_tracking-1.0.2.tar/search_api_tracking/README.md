INTRODUCTION
------------

* For a full description of the module, visit the project page:
  https://www.drupal.org/project/search_api_tracking

REQUIREMENTS
------------

This module requires the following modules:
* Search API

INSTALLATION
------------

* Install as you would normally install a contributed Drupal module. Visit
  https://www.drupal.org/node/895232/ for further information.

CONFIGURATION
-------------

* Adjust the view where necessary.
* Visit the settings page and correct the ID/CSS selectors.


MAINTAINERS
-----------

Current maintainers:
* Michael Schuddings - https://www.drupal.org/u/mschudders
