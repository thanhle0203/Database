<div id="omega-screen--indicator" class="clearfix">
  <div class="ologo">
    <?php print($logo); ?>
  </div>
  <div class="indicator-data">
    <div class="screen-size">
      <h5>@screen width:</h5>
      <span class="data"></span>
    </div>
    <div class="theme-name">
      <h5>@theme:</h5>
      <span class="data"></span>
    </div>
    <div class="screen-query">
      <h5>@breakpoints:</h5>
      <span class="data"></span>
    </div>
    <div class="screen-layout">
      <h5>@layout:</h5>
      <span class="data"></span>
    </div>
  </div>
</div>