##########################################################################################
 _____                      _____ _         
|     |_____ ___ ___ ___   |   __|_|_ _ ___ 
|  |  |     | -_| . | .'|  |   __| | | | -_|
|_____|_|_|_|___|_  |__,|  |__|  |_|\_/|___|
                |___|                       
                    
##########################################################################################

##########################################################################################
##### Omega Five Theme for Drupal 7
##########################################################################################


Project Page:   http://drupal.org/project/omega
Documentation:  
Issue Queue:    http://drupal.org/project/issues/omega
Usage Stats:    http://drupal.org/project/usage/omega
Maintainer(s):  Jake Strawn
                http://drupal.org/user/159141
                http://twitter.com/himerus
##########################################################################################

Templates Directory
===================

Templates placed in this directory overwrite templates provided by either Omega Five Core, 
or other templates provided by Drupal modules and core.

More information on Drupal templates and template suggestions: https://www.drupal.org/node/1089662