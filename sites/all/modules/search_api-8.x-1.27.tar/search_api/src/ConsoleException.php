<?php

namespace Drupal\search_api;

/**
 * Represents an exception that occurred in the console code of Search API.
 */
class ConsoleException extends SearchApiException {}
